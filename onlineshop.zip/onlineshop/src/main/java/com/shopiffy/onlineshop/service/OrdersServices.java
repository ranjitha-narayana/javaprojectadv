//package com.shopiffy.onlineshop.service;
//
//import com.shopiffy.onlineshop.model.Product;
//import com.shopiffy.onlineshop.repository.OrderRepository;
//import com.shopiffy.onlineshop.repository.ProductRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//import java.util.Optional;
//
//@Service
//public class OrdersServices {
//
//    @Autowired
//    OrderRepository orderRepository;
//
//    @Autowired
//    ProductRepository productRepository;
//
//    public List<Product> getAllProduct() { return orderRepository.findAll(); }
//
//    public void addProduct(Product product){
//        orderRepository.save(product);
//    }
//    public void removeProductById(long id){
//        orderRepository.deleteById(id);
//    }
//    public Optional<Product> getProductById(long id){
//        return orderRepository.findById(id);
//    }
//
//    public List<Product> getAllProductsByCategoryId(int id){
//        return orderRepository.findAllByProduct_Id(id);
//    }
//
//
//
//}
