package com.shopiffy.onlineshop.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ApplicationStatus {

    @GetMapping("/appstatus")
    public String hello() {
        return "hello dev! welcome back you got some bugs";
    }
}
