package com.shopiffy.onlineshop.repository;

import com.shopiffy.onlineshop.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role,Integer> {


}
